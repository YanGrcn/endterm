package tictac;

import java.util.Scanner;

public class Main { //Main part
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
	int exit=0;
	while(exit!=1) {
		System.out.println("Choose your gamemode:");
		System.out.println("1. With bot.");
		System.out.println("2. 2 persons.");
		int Gamemode=scan.nextInt();
		if(Gamemode==2) {
			TicTacWithUser a = new TicTacWithUser();
			a.Victory=0;
			while(a.Victory!=1) {
			a.getGameBoard();
			System.out.println("First person choose your row and column.");
			int row=scan.nextInt();
			int column=scan.nextInt();
			a.GamePositionAdd(row, column, "Person");
			a.getGameBoard();
			a.TieTest();
			a.WinnerTest();
			a.VictoryTest();
			if(a.Victory!=1) {
			System.out.println("Second person choose your row and column.");
			row=scan.nextInt();
			column=scan.nextInt();
			a.GamePositionAdd(row, column, "Person2");
			a.getGameBoard();
			a.WinnerTest();
			a.VictoryTest();
			}
			}
		}
		else if(Gamemode==1) {
		TicTacWithBot a = new TicTacWithBot(); 
		a.Victory=0;
	while(a.Victory!=1) {
		a.getGameBoard();
		System.out.println("Choose your row and column.");
		int row=scan.nextInt();
		int column=scan.nextInt();
		a.GamePositionAdd(row, column, "Person");
		a.getGameBoard();
		a.TieTest();
		a.WinnerTest();
		a.VictoryTest();
		if(a.Victory!=1) {
		a.BotsTurn();
		a.getGameBoard();
		a.WinnerTest();
		a.VictoryTest();
		}
	}
	}
	System.out.println("Choose your option:");
	System.out.println("1.Play again");
	System.out.println("2.Exit");
	if(scan.nextInt()==2) {
		exit=1;
	}
	}
	}
}
