package tictac;

public class TicTacMainGame {
	private String VictoryOfWho="NoWin";
	private int Victory=0;
	public int GetVictory() {
		return this.Victory;
	}
	public void SetVictory() {
		this.Victory=1;
	}
	public void SetVictoryToZero() {
		this.Victory=0;
	}
	public String GetVictoryOfWho() {
		return this.VictoryOfWho;
	}
	public void SetVictoryOfWho(String Winner) {
		this.VictoryOfWho=Winner;
	}
	//Making a Gameboard
	private char[][] GameBoard={{' ','|',' ','|',' '},{'-','+','-','+','-'},{' ','|',' ','|',' '},{'-','+','-','+','-'},{' ','|',' ','|',' '}};
	//getting a Gameboard
	public void getGameBoard() {
		System.out.println("Your gameboard for now: ");
		for (int i=0;i<5;i++) {
			for (int j=0;j<5;j++) {
			System.out.print(GameBoard[i][j]);
			}
		System.out.println();
		}
		System.out.println();
	}
	//check for a draw
		public void TieTest() {
			if(Victory!=1) {
				int Tie=1;
				for (int i=1;i<4;i++) {
					for(int j=1;j<4;j++) {
						if (GamePositionCheck(i,j)!='X' & GamePositionCheck(i,j)!='O') {
							Tie=0;
						}
					}
				}
			    if(Tie==1) {
			    	SetVictoryOfWho("Tie");
			    }
			}
			
		}
	//Adding X or O to the Gameboard
	public void GamePositionAdd(int Row, int Column, String Gamer) {
		if (Row==1) {
		Row=Row-1;
		}
		else if (Row==2) {
		Row=Row;
		}
		else if (Row==3) {
		Row=Row+1;
		}
		else {
		System.out.println ("Wrong position!");
		}
		if (Column==1) {
		Column=Column-1;
		}
		else if (Column==2) {
		Column=Column;
		}
		else if (Column==3) {
		Column=Column+1;
		}
		else {
		System.out.println ("Wrong position!");
		}
		if (Gamer=="Person") {
			this.GameBoard[Row][Column]='X';
		}
		else {
			this.GameBoard[Row][Column]='O';
		}
	}
	//Checking and returning X or O on direct position
	public char GamePositionCheck(int Row, int Column) {
		if (Row==1) {
		Row=Row-1;
		}
		else if (Row==2) {
		Row=Row;
		}
		else if (Row==3) {
		Row=Row+1;
		}
		if (Column==1) {
		Column=Column-1;
		}
		else if (Column==2) {
		Column=Column;
		}
		else if (Column==3) {
		Column=Column+1;
		}
		return this.GameBoard[Row][Column];
	}
	//returning a message about tie
	public String Tie() {
		return "Game over." + GetVictoryOfWho() + "!";
	}
}
