package tictac;

import java.util.Random;

public class TicTacWithUser extends TicTacMainGame implements TicTacMainFunc{
	//Checking if there are a winner
	public void WinnerTest(){
		if(GamePositionCheck(1,1)==GamePositionCheck(1,2) & GamePositionCheck(1,2)==GamePositionCheck(1,3) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(1,2)!=' ' & GamePositionCheck(1,3)!=' '){
			if (GamePositionCheck(1,1)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(1,1)=='O') {
			    SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(2,1)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(2,3) & GamePositionCheck(2,1)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(2,3)!=' ') {
			if (GamePositionCheck(2,1)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(2,1)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(3,1)==GamePositionCheck(3,2) & GamePositionCheck(3,2)==GamePositionCheck(3,3) & GamePositionCheck(3,1)!=' ' & GamePositionCheck(3,2)!=' ' & GamePositionCheck(3,3)!=' ') {
			if (GamePositionCheck(3,1)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(3,1)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(1,1)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(3,3) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(3,3)!=' ') {
			if (GamePositionCheck(1,1)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(1,1)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(3,1)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(1,3) & GamePositionCheck(3,1)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(1,3)!=' ') {
			if (GamePositionCheck(3,1)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(3,1)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(1,1)==GamePositionCheck(2,1) & GamePositionCheck(2,1)==GamePositionCheck(3,1) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(2,1)!=' ' & GamePositionCheck(3,1)!=' ') {
			if (GamePositionCheck(1,1)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(1,1)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(1,2)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(3,2) & GamePositionCheck(1,2)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(2,2)!=' ') {
			if (GamePositionCheck(1,2)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(1,2)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
		if(GamePositionCheck(1,3)==GamePositionCheck(2,3) & GamePositionCheck(2,3)==GamePositionCheck(3,3) & GamePositionCheck(1,3)!=' ' & GamePositionCheck(2,3)!=' ' & GamePositionCheck(3,3)!=' ') {
			if (GamePositionCheck(1,3)=='X') {
				SetVictoryOfWho("Person1");
			}
			else if (GamePositionCheck(1,3)=='O') {
				SetVictoryOfWho("Person2");
			}
		}
	}
	
	//win check
	public void VictoryTest() {
		if (GetVictoryOfWho()!="NoWin" & GetVictoryOfWho()!="Tie") {
			SetVictory();
			System.out.println(Victory());
		}
		else if(GetVictoryOfWho()=="Tie") {
			SetVictory();
			System.out.println(Tie());
		}
	}
	//returning the winner
	public String Victory() {
		return "Game over. " + GetVictoryOfWho() + " won!";
	}
}
