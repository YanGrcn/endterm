package tictac;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main { //Main part
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
	int exit=0;
	int FirstPlayerScore=0;
	int SecondPlayerScore=0;
	int ChangeGameMode=1;
	int Gamemode=-1;
	while(exit!=1) {
		if(ChangeGameMode==1) {
		FirstPlayerScore=0;
		SecondPlayerScore=0;
		System.out.println("Choose your gamemode:");
		System.out.println("1. With bot.");
		System.out.println("2. 2 persons.");
		Gamemode=scan.nextInt();
		}
		if(Gamemode==2) {
			TicTacWithUser a = new TicTacWithUser();
			a.SetVictoryToZero();
			while(a.GetVictory()!=1) {
			a.getGameBoard();
			System.out.println("First person choose your row and column.");
			int row=scan.nextInt();
			int column=scan.nextInt();
			a.GamePositionAdd(row, column, "Person");
			a.getGameBoard();
			a.TieTest();
			a.WinnerTest();
			a.VictoryTest();
			if(a.GetVictory()!=1) {
			System.out.println("Second person choose your row and column.");
			row=scan.nextInt();
			column=scan.nextInt();
			a.GamePositionAdd(row, column, "Person2");
			a.getGameBoard();
			a.WinnerTest();
			a.VictoryTest();
			}
			if(a.GetVictoryOfWho()=="Person1"){
				FirstPlayerScore+=1;
			}
            if(a.GetVictoryOfWho()=="Person2"){
            	SecondPlayerScore+=1;
			}
			}
		}
		else if(Gamemode==1) {
		TicTacWithBot a = new TicTacWithBot(); 
		a.SetVictoryToZero();
	while(a.GetVictory()!=1) {
		a.getGameBoard();
		System.out.println("Choose your row and column.");
		int row=scan.nextInt();
		int column=scan.nextInt();
		a.GamePositionAdd(row, column, "Person");
		a.getGameBoard();
		a.TieTest();
		a.WinnerTest();
		a.VictoryTest();
		if(a.GetVictory()!=1) {
		a.BotsTurn();
		a.getGameBoard();
		a.WinnerTest();
		a.VictoryTest();
		}
		if(a.GetVictoryOfWho()=="Person"){
			FirstPlayerScore+=1;
		}
        if(a.GetVictoryOfWho()=="Bot"){
        	SecondPlayerScore+=1;
		}
	}
	}
	System.out.println("Choose your option:");
	System.out.println("1.Play again");
	System.out.println("2.Exit");
	System.out.println("3.Change Gamemode");
	int i=scan.nextInt();
    if(i==1) {
		ChangeGameMode=0;
	}
	if(i==3) {
		ChangeGameMode=1;
		try(FileWriter writer = new FileWriter("TicTacScore.txt", false))
	    {
	    	String str = Integer.toString(FirstPlayerScore);
	        writer.append(str+'\n');
	        String str2 = Integer.toString(SecondPlayerScore);
	        writer.append(str2);
	        writer.flush();
	    }
	        catch(IOException ex){
	            
	            System.out.println(ex.getMessage());
	    }
	    try {
	        File file = new File("TicTacScore.txt");
	        FileReader fr = new FileReader(file);
	        BufferedReader reader = new BufferedReader(fr);
	        String line = reader.readLine();
	        System.out.println("First player score:");
	        System.out.println(line);
	        line = reader.readLine();
            System.out.println("Second player score:");
            System.out.println(line);
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	if(i==2) {
		try(FileWriter writer = new FileWriter("TicTacScore.txt", false))
	    {
	    	String str = Integer.toString(FirstPlayerScore);
	        writer.append(str+'\n');
	        String str2 = Integer.toString(SecondPlayerScore);
	        writer.append(str2);
	        writer.flush();
	    }
	        catch(IOException ex){
	            
	            System.out.println(ex.getMessage());
	    }
	    try {
	        File file = new File("TicTacScore.txt");
	        FileReader fr = new FileReader(file);
	        BufferedReader reader = new BufferedReader(fr);
	        String line = reader.readLine();
	        System.out.println("First player score:");
	        System.out.println(line);
	        line = reader.readLine();
            System.out.println("Second player score:");
            System.out.println(line);
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		exit=1;
	}
	}
	}
}
