package tictac;

import java.util.Random;

public class TicTacWithBot extends TicTacMainGame implements TicTacMainFunc{
	//Checking if there are a winner
	public void WinnerTest(){
		if(GamePositionCheck(1,1)==GamePositionCheck(1,2) & GamePositionCheck(1,2)==GamePositionCheck(1,3) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(1,2)!=' ' & GamePositionCheck(1,3)!=' '){
			if (GamePositionCheck(1,1)=='X') {
			SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(1,1)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(2,1)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(2,3) & GamePositionCheck(2,1)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(2,3)!=' ') {
			if (GamePositionCheck(2,1)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(2,1)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(3,1)==GamePositionCheck(3,2) & GamePositionCheck(3,2)==GamePositionCheck(3,3) & GamePositionCheck(3,1)!=' ' & GamePositionCheck(3,2)!=' ' & GamePositionCheck(3,3)!=' ') {
			if (GamePositionCheck(3,1)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(3,1)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(1,1)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(3,3) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(3,3)!=' ') {
			if (GamePositionCheck(1,1)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(1,1)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(3,1)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(1,3) & GamePositionCheck(3,1)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(1,3)!=' ') {
			if (GamePositionCheck(3,1)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(3,1)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(1,1)==GamePositionCheck(2,1) & GamePositionCheck(2,1)==GamePositionCheck(3,1) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(2,1)!=' ' & GamePositionCheck(3,1)!=' ') {
			if (GamePositionCheck(1,1)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(1,1)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(1,2)==GamePositionCheck(2,2) & GamePositionCheck(2,2)==GamePositionCheck(3,2) & GamePositionCheck(1,2)!=' ' & GamePositionCheck(2,2)!=' ' & GamePositionCheck(2,2)!=' ') {
			if (GamePositionCheck(1,2)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(1,2)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
		if(GamePositionCheck(1,3)==GamePositionCheck(2,3) & GamePositionCheck(2,3)==GamePositionCheck(3,3) & GamePositionCheck(1,3)!=' ' & GamePositionCheck(2,3)!=' ' & GamePositionCheck(3,3)!=' ') {
			if (GamePositionCheck(1,3)=='X') {
				SetVictoryOfWho("Person");
			}
			else if (GamePositionCheck(1,3)=='O') {
				SetVictoryOfWho("Bot");
			}
		}
	}
	//Bots turn, how he adds a signs
	public void BotsTurn() {
		int Used=0;
		int Row=-1;
		int Column=-1;
		if(((GamePositionCheck(1,1)==GamePositionCheck(1,2) & GamePositionCheck(1,1)=='O' & GamePositionCheck(1,2)=='O') || (GamePositionCheck(1,2)==GamePositionCheck(1,3) & GamePositionCheck(1,2)=='O' & GamePositionCheck(1,3)=='O')
				|| (GamePositionCheck(1,1)==GamePositionCheck(1,3)& GamePositionCheck(1,1)=='O' & GamePositionCheck(1,3)=='O')) & Used==0) {
			if (GamePositionCheck(1,1)!='X' & GamePositionCheck(1,1)!='O') {
				Row=1;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(1,2)!='X' & GamePositionCheck(1,2)!='O') {
				Row=1;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(1,3)!='X' & GamePositionCheck(1,3)!='O') {
				Row=1;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(2,1)==GamePositionCheck(2,2)& GamePositionCheck(2,1)=='O' & GamePositionCheck(2,2)=='O') || (GamePositionCheck(2,2)==GamePositionCheck(2,3)& GamePositionCheck(2,2)=='O' & GamePositionCheck(2,3)=='O')
				|| (GamePositionCheck(2,1)==GamePositionCheck(2,3)& GamePositionCheck(2,1)=='O' & GamePositionCheck(2,3)=='O')) & Used==0) {
			if (GamePositionCheck(2,1)!='X' & GamePositionCheck(2,1)!='O') {
				Row=2;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(2,3)!='X' & GamePositionCheck(2,3)!='O') {
				Row=2;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(3,1)==GamePositionCheck(3,2)& GamePositionCheck(3,1)=='O' & GamePositionCheck(3,2)=='O') || (GamePositionCheck(3,2)==GamePositionCheck(3,3)& GamePositionCheck(3,2)=='O' & GamePositionCheck(3,3)=='O') 
				|| (GamePositionCheck(3,1)==GamePositionCheck(3,3)& GamePositionCheck(3,1)=='O' & GamePositionCheck(3,3)=='O')) & Used==0) {
			if (GamePositionCheck(3,1)!='X' & GamePositionCheck(3,1)!='O') {
				Row=3;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(3,2)!='X' & GamePositionCheck(3,2)!='O') {
				Row=3;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(3,3)!='X' & GamePositionCheck(3,3)!='O') {
				Row=3;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,1)==GamePositionCheck(2,2)& GamePositionCheck(1,1)=='O' & GamePositionCheck(2,2)=='O') || (GamePositionCheck(2,2)==GamePositionCheck(3,3)& GamePositionCheck(2,2)=='O' & GamePositionCheck(3,3)=='O')
				|| (GamePositionCheck(1,1)==GamePositionCheck(3,3)& GamePositionCheck(1,1)=='O' & GamePositionCheck(3,3)=='O')) & Used==0) {
			if (GamePositionCheck(1,1)!='X' & GamePositionCheck(1,1)!='O') {
				Row=1;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(3,3)!='X' & GamePositionCheck(3,3)!='O') {
				Row=3;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(3,1)==GamePositionCheck(2,2)& GamePositionCheck(3,1)=='O' & GamePositionCheck(2,2)=='O') || (GamePositionCheck(2,2)==GamePositionCheck(1,3)& GamePositionCheck(2,2)=='O' & GamePositionCheck(1,3)=='O')
				|| (GamePositionCheck(3,1)==GamePositionCheck(1,3)& GamePositionCheck(3,1)=='O' & GamePositionCheck(1,3)=='O')) & Used==0) {
			if (GamePositionCheck(3,1)!='X' & GamePositionCheck(3,1)!='O') {
				Row=3;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(1,3)!='X' & GamePositionCheck(1,3)!='O') {
				Row=1;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,1)==GamePositionCheck(2,1)& GamePositionCheck(1,1)=='O' & GamePositionCheck(2,1)=='O') || (GamePositionCheck(2,1)==GamePositionCheck(3,1)& GamePositionCheck(2,1)=='O' & GamePositionCheck(3,1)=='O')
				|| (GamePositionCheck(1,1)==GamePositionCheck(3,1)& GamePositionCheck(1,1)=='O' & GamePositionCheck(3,1)=='O')) & Used==0) {
			if (GamePositionCheck(1,1)!='X' & GamePositionCheck(1,1)!='O') {
				Row=1;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,1)!='X' & GamePositionCheck(2,1)!='O') {
				Row=2;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(3,1)!='X' & GamePositionCheck(3,1)!='O') {
				Row=3;
				Column=1;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,2)==GamePositionCheck(2,2)& GamePositionCheck(1,2)=='O' & GamePositionCheck(2,2)=='O') || (GamePositionCheck(2,2)==GamePositionCheck(3,2)& GamePositionCheck(2,2)=='O' & GamePositionCheck(3,2)=='O')
				|| (GamePositionCheck(1,2)==GamePositionCheck(3,2)& GamePositionCheck(1,2)=='O' & GamePositionCheck(3,2)=='O')) & Used==0) {
			if (GamePositionCheck(1,2)!='X' & GamePositionCheck(1,2)!='O') {
				Row=1;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(3,2)!='X' & GamePositionCheck(3,2)!='O') {
				Row=3; 
				Column=2;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,3)==GamePositionCheck(2,3) & GamePositionCheck(1,3)=='O' & GamePositionCheck(2,3)=='O') || (GamePositionCheck(2,3)==GamePositionCheck(3,3)& GamePositionCheck(2,3)=='O' & GamePositionCheck(3,3)=='O')
				|| (GamePositionCheck(1,3)==GamePositionCheck(3,3)& GamePositionCheck(1,3)=='O' & GamePositionCheck(3,3)=='O')) & Used==0) {
			if (GamePositionCheck(1,3)!='X' & GamePositionCheck(1,3)!='O') {
				Row=1;
				Column=3;
				Used+=1;
			}
			else if (GamePositionCheck(2,3)!='X' & GamePositionCheck(2,3)!='O') {
				Row=2;
				Column=3;
				Used+=1;
			}
			else if (GamePositionCheck(3,3)!='X' & GamePositionCheck(3,3)!='O') {
				Row=3;
				Column=3;
				Used+=1;
			}
		}
		
		
		if(((GamePositionCheck(1,1)==GamePositionCheck(1,2) & GamePositionCheck(1,1)!=' ' & GamePositionCheck(1,2)!=' ') || (GamePositionCheck(1,2)==GamePositionCheck(1,3) & GamePositionCheck(1,2)!=' ' & GamePositionCheck(1,3)!=' ')
				|| (GamePositionCheck(1,1)==GamePositionCheck(1,3)& GamePositionCheck(1,1)!=' ' & GamePositionCheck(1,3)!=' ')) & Used==0) {
			if (GamePositionCheck(1,1)!='X' & GamePositionCheck(1,1)!='O') {
				Row=1;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(1,2)!='X' & GamePositionCheck(1,2)!='O') {
				Row=1;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(1,3)!='X' & GamePositionCheck(1,3)!='O') {
				Row=1;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(2,1)==GamePositionCheck(2,2)& GamePositionCheck(2,1)!=' ' & GamePositionCheck(2,2)!=' ') || (GamePositionCheck(2,2)==GamePositionCheck(2,3)& GamePositionCheck(2,2)!=' ' & GamePositionCheck(2,3)!=' ')
				|| (GamePositionCheck(2,1)==GamePositionCheck(2,3)& GamePositionCheck(2,1)!=' ' & GamePositionCheck(2,3)!=' ')) & Used==0) {
			if (GamePositionCheck(2,1)!='X' & GamePositionCheck(2,1)!='O') {
				Row=2;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(2,3)!='X' & GamePositionCheck(2,3)!='O') {
				Row=2;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(3,1)==GamePositionCheck(3,2)& GamePositionCheck(3,1)!=' ' & GamePositionCheck(3,2)!=' ') || (GamePositionCheck(3,2)==GamePositionCheck(3,3)& GamePositionCheck(3,2)!=' ' & GamePositionCheck(3,3)!=' ') 
				|| (GamePositionCheck(3,1)==GamePositionCheck(3,3)& GamePositionCheck(3,1)!=' ' & GamePositionCheck(3,3)!=' ')) & Used==0) {
			if (GamePositionCheck(3,1)!='X' & GamePositionCheck(3,1)!='O') {
				Row=3;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(3,2)!='X' & GamePositionCheck(3,2)!='O') {
				Row=3;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(3,3)!='X' & GamePositionCheck(3,3)!='O') {
				Row=3;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,1)==GamePositionCheck(2,2)& GamePositionCheck(1,1)!=' ' & GamePositionCheck(2,2)!=' ') || (GamePositionCheck(2,2)==GamePositionCheck(3,3)& GamePositionCheck(2,2)!=' ' & GamePositionCheck(3,3)!=' ')
				|| (GamePositionCheck(1,1)==GamePositionCheck(3,3)& GamePositionCheck(1,1)!=' ' & GamePositionCheck(3,3)!=' ')) & Used==0) {
			if (GamePositionCheck(1,1)!='X' & GamePositionCheck(1,1)!='O') {
				Row=1;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(3,3)!='X' & GamePositionCheck(3,3)!='O') {
				Row=3;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(3,1)==GamePositionCheck(2,2)& GamePositionCheck(3,1)!=' ' & GamePositionCheck(2,2)!=' ') || (GamePositionCheck(2,2)==GamePositionCheck(1,3)& GamePositionCheck(2,2)!=' ' & GamePositionCheck(1,3)!=' ')
				|| (GamePositionCheck(3,1)==GamePositionCheck(1,3)& GamePositionCheck(3,1)!=' ' & GamePositionCheck(1,3)!=' ')) & Used==0) {
			if (GamePositionCheck(3,1)!='X' & GamePositionCheck(3,1)!='O') {
				Row=3;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(1,3)!='X' & GamePositionCheck(1,3)!='O') {
				Row=1;
				Column=3;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,1)==GamePositionCheck(2,1)& GamePositionCheck(1,1)!=' ' & GamePositionCheck(2,1)!=' ') || (GamePositionCheck(2,1)==GamePositionCheck(3,1)& GamePositionCheck(2,1)!=' ' & GamePositionCheck(3,1)!=' ')
				|| (GamePositionCheck(1,1)==GamePositionCheck(3,1)& GamePositionCheck(1,1)!=' ' & GamePositionCheck(3,1)!=' ')) & Used==0) {
			if (GamePositionCheck(1,1)!='X' & GamePositionCheck(1,1)!='O') {
				Row=1;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(2,1)!='X' & GamePositionCheck(2,1)!='O') {
				Row=2;
				Column=1;
				Used+=1;
			}
			else if (GamePositionCheck(3,1)!='X' & GamePositionCheck(3,1)!='O') {
				Row=3;
				Column=1;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,2)==GamePositionCheck(2,2)& GamePositionCheck(1,2)!=' ' & GamePositionCheck(2,2)!=' ') || (GamePositionCheck(2,2)==GamePositionCheck(3,2)& GamePositionCheck(2,2)!=' ' & GamePositionCheck(3,2)!=' ')
				|| (GamePositionCheck(1,2)==GamePositionCheck(3,2)& GamePositionCheck(1,2)!=' ' & GamePositionCheck(3,2)!=' ')) & Used==0) {
			if (GamePositionCheck(1,2)!='X' & GamePositionCheck(1,2)!='O') {
				Row=1;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(2,2)!='X' & GamePositionCheck(2,2)!='O') {
				Row=2;
				Column=2;
				Used+=1;
			}
			else if (GamePositionCheck(3,2)!='X' & GamePositionCheck(3,2)!='O') {
				Row=3; 
				Column=2;
				Used+=1;
			}
		}
		if(((GamePositionCheck(1,3)==GamePositionCheck(2,3)& GamePositionCheck(1,3)!=' ' & GamePositionCheck(2,3)!=' ') || (GamePositionCheck(2,3)==GamePositionCheck(3,3)& GamePositionCheck(2,3)!=' ' & GamePositionCheck(3,3)!=' ')
				|| (GamePositionCheck(1,3)==GamePositionCheck(3,3)& GamePositionCheck(1,3)!=' ' & GamePositionCheck(3,3)!=' ')) & Used==0) {
			if (GamePositionCheck(1,3)!='X' & GamePositionCheck(1,3)!='O') {
				Row=1;
				Column=3;
				Used+=1;
			}
			else if (GamePositionCheck(2,3)!='X' & GamePositionCheck(2,3)!='O') {
				Row=2;
				Column=3;
				Used+=1;
			}
			else if (GamePositionCheck(3,3)!='X' & GamePositionCheck(3,3)!='O') {
				Row=3;
				Column=3;
				Used+=1;
			}
		}
		if (Used==0 & GetVictoryOfWho()!="Tie"){
			do {
			Random rand = new Random();
			Row=rand.nextInt(3)+1;
			Column=rand.nextInt(3)+1;
			}
			while (GamePositionCheck(Row,Column)=='O' || GamePositionCheck(Row,Column)=='X');
		}
		if (GetVictoryOfWho()!="Tie"){
		GamePositionAdd(Row, Column, "Bot");
		}
	}
	//win check
	public void VictoryTest() {
		if (GetVictoryOfWho()!="NoWin" & GetVictoryOfWho()!="Tie") {
			SetVictory();
			System.out.println(Victory());
		}
		else if(GetVictoryOfWho()=="Tie") {
			SetVictory();
			System.out.println(Tie());
		}
	}
	//returning the winner
	public String Victory() {
		return "Game over. " + GetVictoryOfWho() + " won!";
	}
}
