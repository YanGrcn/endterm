package tictac;

public interface TicTacMainFunc {
public void VictoryTest();
public void WinnerTest();
public String Victory();
}
